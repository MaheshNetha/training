import axios from 'axios'

export const IPOServices = {
    getIPOs,
    getDetailsOfIPO,
   
}

function getIPOs(){

    axios.get('url',{headers:{}})
}


function getDetailsOfIPO(payload){
    axios.post('url',payload,{headers:{}})
}


