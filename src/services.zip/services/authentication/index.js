import axios from 'axios'

export const authServices = {
    login,
    logout,
    registration,
    sendOTP,
    validateOTP,
    forgotPassword,
    updateForgotPassword,
}

function login(payload){

    axios.post('url',payload,{headers:{}})
}
function logout(){

}

function registration(payload){
    axios.post('url',payload,{headers:{}})

}

function sendOTP(payload){
    axios.post('url',payload,{headers:{}})

}
function validateOTP(payload){
    axios.post('url',payload,{headers:{}})

}
function forgotPassword(payload){
    axios.post('url',payload,{headers:{}})

}

function updateForgotPassword(payload){
    axios.post('url',payload,{headers:{}})

}

