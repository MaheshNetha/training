import axios from 'axios'

export const profileServices = {
    getUserProfile,
    updateUserProfile,
   
}

function getUserProfile(){

    axios.get('url',{headers:{}})
}


function updateUserProfile(payload){
    axios.post('url',payload,{headers:{}})
}


